
import { Row, Col, Card } from "react-bootstrap";
import img2 from "../Images/Icon.png";
import img3 from "../Images/Icon (1).png";
import img4 from "../Images/Icon (2).png";

const CategorySection = () => {
  return (
    <>
    </>
    // <div className="container my-5">

    //   <Row className="g-3">
    //     <Col xs={12} md={4}>
    //       <Card className="h-100" style={{border:"none"}}>
    //         <Card.Body>
    //           <Card.Img variant="top" src={img2} style={{height:"64px",width:"64px"}} />
    //           <Card.Title  style={{ fontSize: '24px', fontWeight: '600' }}>
    //             Nibh viverra
    //           </Card.Title>
    //           <Card.Text className="text-muted">
    //             Sit bibendum donec dolor fames neque vulputate non sit aliquam. Consequat turpis natoque leo, massa.
    //           </Card.Text>
    //         </Card.Body>
    //       </Card>
    //     </Col>

    //     <Col xs={12} md={4}>
    //       <Card className="h-100" style={{border:"none"}}>
    //         <Card.Body>
    //           <Card.Img variant="top" src={img3}  style={{height:"64px",width:"64px"}}  />
    //           <Card.Title className="text-[#78350F]" style={{ fontSize: '24px', fontWeight: '600' }}>
    //             Cursus amet
    //           </Card.Title>
    //           <Card.Text className="text-muted">
    //             Sit bibendum donec dolor fames neque vulputate non sit aliquam. Consequat turpis natoque leo, massa.
    //           </Card.Text>
    //         </Card.Body>
    //       </Card>
    //     </Col>

    //     <Col xs={12} md={4}>
    //       <Card className="h-100" style={{border:"none"}}>
    //         <Card.Body>
    //           <Card.Img variant="top" src={img4}  style= {{height:"64px",width:"64px"}}  />
    //           <Card.Title className="text-[#78350F]" style={{ fontSize: '24px', fontWeight: '600' }}>
    //             Ipsum fermentum
    //           </Card.Title>
    //           <Card.Text className="text-muted">
    //             Sit bibendum donec dolor fames neque vulputate non sit aliquam. Consequat turpis natoque leo, massa.
    //           </Card.Text>
    //         </Card.Body>
    //       </Card>
    //     </Col>
    //   </Row>
    // </div>
  );
};

export default CategorySection;
